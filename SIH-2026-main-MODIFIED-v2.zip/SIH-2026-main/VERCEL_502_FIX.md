# Vercel 502 / Bad Gateway Fix

## What was fixed

1. Vercel Functions are pinned to Node.js 22.x.
2. `api/index.ts` now lazy-loads the Express application and returns a JSON error instead of allowing an initialization exception to become a generic 502.
3. The `/api/:path*` rewrite is kept explicit for the single `api/index.ts` function.
4. `package.json` now pins the Node major version to `22.x`.

## Why

Vercel documents `NO_RESPONSE_FROM_FUNCTION` as a 502 that can occur when a function crashes or fails to return a response. The project uses Node's `node:sqlite`, so keeping the API on Node 22 is intentional.

## Verify after deployment

Open:

- `/api/health`
- `/api/db/stats`

If `/api/health` returns JSON with `status: "ok"`, the API function is alive.

If it returns `API initialization failed`, the JSON now exposes the startup error instead of hiding it behind a 502.
