# ARGUS / SIH 2026 prototype modifications

This revision keeps the existing application intact and adds SIH-focused hardening around the existing smart-matching and cooperative workflow.

## Added
- `server/matching.ts`: explainable ARGUS Match Engine v1.
  - Filters for verified + available workers.
  - Enforces worker skill compatibility and service radius.
  - Scores skill, proximity, availability, verification, reputation, and emergency readiness.
  - Returns the top five matches with reasons and a score breakdown.
- `GET /api/bookings/:id/matches`: exposes the match engine for a booking.
- Customer worker cards now show `ARGUS Match xx/100` using the existing matching utility.
- `api.getSmartMatches(bookingId)` client API helper.

## Security hardening
- Worker-owned skill checks, verification submissions, geo updates, and realtime updates now require a valid worker session and ownership of the worker record.
- Federation worker approval/rejection now requires an authenticated admin session.
- Booking acceptance now checks that the worker is verified and available, validates the ARGUS matching criteria, and uses an atomic open-booking update to reduce double-claim races.

## Compatibility
- Existing customer booking flow is preserved.
- Existing Firebase/SQLite architecture is preserved.
- No API keys or secrets were added.

## Verification note
The source package did not contain installed `node_modules`, so a full local TypeScript/Vite build could not be completed in this environment. The original project dependencies remain unchanged.
