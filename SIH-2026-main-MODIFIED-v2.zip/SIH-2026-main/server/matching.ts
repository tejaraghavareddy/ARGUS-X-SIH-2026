
function calculateDistanceKm(a: { lat: number; lng: number }, b: { lat: number; lng: number }): number {
  const R = 6371;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const x = Math.sin(dLat / 2) ** 2 + Math.cos(a.lat * Math.PI / 180) * Math.cos(b.lat * Math.PI / 180) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
}

function estimateTravelTimeMinutes(distanceKm: number): number {
  return Math.max(5, Math.round((distanceKm / 22) * 60) + 3);
}


export interface MatchInput {
  serviceCategory: string;
  lat: number;
  lng: number;
  isEmergency?: boolean;
}

export interface WorkerMatch {
  workerId: string;
  workerName: string;
  primarySkill: string;
  matchScore: number;
  distanceKm: number;
  etaMinutes: number;
  reasons: string[];
  scoreBreakdown: {
    skill: number;
    proximity: number;
    availability: number;
    verification: number;
    reputation: number;
    emergencyReadiness: number;
  };
}

function normalize(value: unknown): string {
  return String(value || '').trim().toLowerCase();
}

function skillMatches(category: string, worker: any): boolean {
  const requested = normalize(category);
  if (!requested || requested === 'all' || requested === 'emergency') return true;
  const skills = [worker.primary_skill, ...JSON.parse(worker.skills_json || '[]')].map(normalize);
  return skills.some((skill) => skill.includes(requested) || requested.includes(skill));
}

export function rankWorkersForRequest(input: MatchInput, workers: any[]): WorkerMatch[] {
  return workers
    .filter((worker) => worker.verification_status === 'verified')
    .filter((worker) => worker.availability === 'available')
    .filter((worker) => skillMatches(input.serviceCategory, worker))
    .map((worker) => {
      const distanceKm = calculateDistanceKm(
        { lat: input.lat, lng: input.lng },
        { lat: Number(worker.lat), lng: Number(worker.lng) },
      );
      const radius = Number(worker.service_radius_km) || 15;
      if (distanceKm > radius) return null;

      const skill = 30;
      const proximity = Math.round(Math.max(0, 20 * (1 - distanceKm / Math.max(radius, 1))));
      const availability = 15;
      const verification = 15;
      const reputation = Math.round(Math.min(10, Math.max(0, (Number(worker.rating) || 0) * 2)));
      const emergencyReadiness = input.isEmergency
        ? (worker.emergency_certified ? 10 : 0)
        : 10;

      const score = Math.min(100, skill + proximity + availability + verification + reputation + emergencyReadiness);
      const reasons: string[] = [
        `Verified cooperative artisan`,
        `${distanceKm.toFixed(1)} km away • ~${estimateTravelTimeMinutes(distanceKm)} min ETA`,
        `${Number(worker.rating || 0).toFixed(1)}/5 community rating`,
      ];
      if (input.isEmergency) {
        reasons.push(worker.emergency_certified ? 'Emergency-certified' : 'Available for emergency dispatch');
      }
      if (distanceKm <= Math.max(3, radius * 0.35)) reasons.push('Inside rapid-response proximity zone');

      return {
        workerId: worker.id,
        workerName: worker.name,
        primarySkill: worker.primary_skill,
        matchScore: score,
        distanceKm: Math.round(distanceKm * 10) / 10,
        etaMinutes: estimateTravelTimeMinutes(distanceKm),
        reasons,
        scoreBreakdown: { skill, proximity, availability, verification, reputation, emergencyReadiness },
      } satisfies WorkerMatch;
    })
    .filter((match): match is WorkerMatch => Boolean(match))
    .sort((a, b) => b.matchScore - a.matchScore || a.distanceKm - b.distanceKm)
    .slice(0, 5);
}
