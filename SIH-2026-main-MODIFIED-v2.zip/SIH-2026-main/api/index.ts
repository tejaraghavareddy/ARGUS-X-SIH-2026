import type { VercelRequest, VercelResponse } from "@vercel/node";

let appPromise: Promise<any> | null = null;

async function getApp() {
  if (!appPromise) {
    appPromise = import("../server/app").then((mod) => mod.default);
  }
  return appPromise;
}

function restoreOriginalPath(req: VercelRequest) {
  // Vercel rewrites /api/<route> to the single /api function.
  // Prefer the original request URL when it is available.
  const original =
    (req.headers["x-matched-path"] as string | undefined) ||
    (req.headers["x-invoke-path"] as string | undefined);

  if (original && original.startsWith("/api/")) {
    req.url = original;
  }
}

export default async function handler(req: VercelRequest, res: VercelResponse) {
  try {
    restoreOriginalPath(req);
    const app = await getApp();
    return app(req as any, res as any);
  } catch (error: any) {
    console.error("[ARGUS Vercel API boot error]", error);
    if (!res.headersSent) {
      return res.status(500).json({
        error: "API initialization failed",
        message: error?.message || "Unknown server error",
        nodeVersion: process.version,
      });
    }
    return res.end();
  }
}
